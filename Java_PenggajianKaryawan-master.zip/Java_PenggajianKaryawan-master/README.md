# Java-tugas
Aplikasi Penggajian Karyawan tugas matkul Pemrograman Desktop (+ JasperReport)
<br/>
Screenshot
![snp1](https://user-images.githubusercontent.com/34033084/112110959-284ff600-8be6-11eb-8316-ff8bda214701.JPG)
<br/><br/>
![snp2](https://user-images.githubusercontent.com/34033084/112110908-1c643400-8be6-11eb-8b40-e1a2b4ea93f2.JPG)


